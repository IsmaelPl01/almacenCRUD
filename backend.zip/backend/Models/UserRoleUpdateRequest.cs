namespace backend.Models;

public class UserRoleUpdateRequest
{
    public string Role { get; set; }
}